package AuthApp.service;

import AuthApp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {
    private static UserService singleInstance = null;
    @Autowired
    private UserRepository userRepository;

    private UserService() {
    }

    public static UserService getInstance() {
        if (singleInstance == null) {
            singleInstance = new UserService();
        }

        return singleInstance;
    }

    public User updateUserName(String email, String name) {
        Optional<User> user = userRepository.getByEmail(email);

        if (user.isPresent()) {
            user.get().setName(name);
            return userRepository.update(user.get());
        } else {
            throw new IllegalArgumentException(String.format("Email address: %s does not exist", email));
        }
    }

    public void updateUserEmail(String email, String newEmail) {
        Optional<User> user = userRepository.getByEmail(email);

        if (user.isPresent()) {
            user.get().setEmail(newEmail);
            userRepository.update(user.get());
        } else {
            throw new IllegalArgumentException(String.format("Email address %s does not match any user", email));
        }
    }

    public void updateUserPassword(String email, String password) {
        Optional<User> user = userRepository.getByEmail(email);

        if (user.isPresent()) {
            user.get().setPassword(password);
            userRepository.update(user.get());
        } else {
            throw new IllegalArgumentException(String.format("Email address %s does not match any user", email));
        }
    }

    public void deleteUser(String email) {
        Optional<User> user = userRepository.getByEmail(email);

        if (user.isPresent()) {
            userRepository.delete(user.get());
        } else {
            throw new IllegalArgumentException(String.format("Email address %s does not match any user", email));
        }
    }
}
