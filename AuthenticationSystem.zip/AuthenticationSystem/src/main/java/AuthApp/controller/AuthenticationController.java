package AuthApp.controller;

import AuthApp.service.AuthenticationService;
import AuthApp.service.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@RequestMapping("/auth")
public class AuthenticationController {
    private static AuthenticationController singleInstance = null;
    @Autowired
    private AuthenticationService authenticationService;

    private AuthenticationController() {
    }

    public static AuthenticationController getInstance() {
        if (singleInstance == null) {
            singleInstance = new AuthenticationController();
        }

        return singleInstance;
    }

    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<User> register(@RequestBody User user) {
        if (!InputValidation.isValidEmail(user.getEmail())) {
            throw new IllegalArgumentException("Invalid email address!");
        }
        if (!InputValidation.isValidName(user.getName())) {
            throw new IllegalArgumentException("Invalid name!");
        }
        if (!InputValidation.isValidPassword(user.getPassword())) {
            throw new IllegalArgumentException("Invalid password!");
        }

        return ResponseEntity.ok(this.authenticationService
                .register(user.getEmail(), user.getName(), user.getPassword()));
    }

    public String login(String email, String password) {
        if (!InputValidation.isValidEmail(email)) {
            throw new IllegalArgumentException("Your email address is invalid!");
        }

        return this.authenticationService.login(email, password);
    }
}
