package AuthApp.controller;

import AuthApp.service.AuthenticationService;
import AuthApp.service.User;
import AuthApp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.AccessDeniedException;

@RestController
@RequestMapping("/user")
public class UserController {
    private static UserController singleInstance = null;
   @Autowired
    private UserService userService;

    private UserController() {
    }

    public static UserController getInstance() {
        if (singleInstance == null) {
            singleInstance = new UserController();
        }

        return singleInstance;
    }

    @RequestMapping(value = "name", method = RequestMethod.PATCH)
    public ResponseEntity<User> updateUserName(@RequestBody User user, @RequestHeader String token) throws IOException {
        if (!InputValidation.isValidName(user.getName())) {
            return ResponseEntity.badRequest().build();
        }

        validateToken(user.getEmail(), token);

        return ResponseEntity.ok(userService.updateUserName(user.getEmail(), user.getName()));
    }

    public void updateUserEmail(String email, String newEmail, String token) throws IOException {
        if (!InputValidation.isValidEmail(newEmail)) {
            throw new IllegalArgumentException(String.format("%s is invalid email!", newEmail));
        }

        validateToken(email, token);
        userService.updateUserEmail(email, newEmail);

        AuthenticationService authenticationService = new AuthenticationService();
        authenticationService.updateTokenEmailKey(email, newEmail);
    }

    public void updateUserPassword(String email, String password, String token) throws IOException {
        if (!InputValidation.isValidPassword(password)) {
            throw new IllegalArgumentException(String.format("%s is invalid password!", password));
        }

        validateToken(email, token);
        userService.updateUserPassword(email, password);
    }

    public void deleteUser(String email, String token) throws IOException {
        validateToken(email, token);
        userService.deleteUser(email);
    }

    private void validateToken(String email, String token) throws IOException {
        AuthenticationService authenticationService = AuthenticationService.getInstance();

        if (!authenticationService.isValidToken(email, token)) {
            throw new AccessDeniedException(String.format("User with email address: %s is not logged in!", email));
        }
    }
}
